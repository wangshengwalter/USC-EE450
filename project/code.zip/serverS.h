// serverS.h
#ifndef SERVERS_H
#define SERVERS_H

#include <iostream>
#include <string>
#include <unistd.h>
#include <sys/socket.h>


int BackendServer_S_UDPSocket
void start_BackendServer_S();

int GetReq(char[] req);

void end_BackendServer_S();

#endif // SERVERS_H
